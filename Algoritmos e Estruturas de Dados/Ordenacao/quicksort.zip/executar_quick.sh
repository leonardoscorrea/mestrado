#!/bin/sh
#DESENVOLVIDO POR Leonardo Correa

gcc ordenacao_quick.c -o quick
./quick

