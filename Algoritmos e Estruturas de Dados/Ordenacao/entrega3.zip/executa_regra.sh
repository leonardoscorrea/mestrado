#!/bin/sh
#DESENVOLVIDO POR Leonardo Correa

gcc regra.c -o regra
./regra

