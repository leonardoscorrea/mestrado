#!/bin/sh
#DESENVOLVIDO POR Leonardo Correa

gcc -p fila.c principalFila.c -o filas -lm
./filas
