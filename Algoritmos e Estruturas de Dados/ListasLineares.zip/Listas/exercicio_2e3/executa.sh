#!/bin/sh
#DESENVOLVIDO POR Leonardo Correa

gcc -p listaInteiros.c ListasLinearesExercicio2e3.c -o lista -lm
./lista
