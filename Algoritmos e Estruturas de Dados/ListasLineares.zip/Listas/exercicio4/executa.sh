#!/bin/sh
#DESENVOLVIDO POR Leonardo Correa

gcc -p listaProduto.c ListaLinearesExercicio4.c -o lista -lm
./lista
