typedef struct linha Linha;
typedef struct matriz Matriz;
void imprimeVetor();
void criaVetor();
void adicionaValorVetor(int valor);
int corteHastes(int valor);
int corteButtomUp(int valor);