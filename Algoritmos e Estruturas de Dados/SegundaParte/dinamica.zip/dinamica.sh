#!/bin/sh
#DESENVOLVIDO POR Leonardo Correa

g++ -p dinamica.cpp dinamicaPrincipal.cpp -o dinamica -lm
./dinamica

