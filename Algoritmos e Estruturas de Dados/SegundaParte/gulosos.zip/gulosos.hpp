typedef struct linha Linha;
void imprimeVetor();
void criaVetor();
void adicionaValorVetor(int valor, int peso);
double mochilaFracionaria(int valor, int tamanho);