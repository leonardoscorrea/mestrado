#!/bin/sh
#DESENVOLVIDO POR Leonardo Correa

g++ -p gulosos.cpp gulososPrincipal.cpp -o gulosos -lm
./gulosos

