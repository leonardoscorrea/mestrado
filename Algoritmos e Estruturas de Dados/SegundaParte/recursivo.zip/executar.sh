#!/bin/sh
#DESENVOLVIDO POR Leonardo Correa

g++ -p recursividade.cpp principalRecursividade.cpp -o recur -lm
./recur

