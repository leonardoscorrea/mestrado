#!/bin/sh
#DESENVOLVIDO POR Leonardo Correa

g++ -p dec.cpp decPrincipal.cpp -o dec -lm
./dec

