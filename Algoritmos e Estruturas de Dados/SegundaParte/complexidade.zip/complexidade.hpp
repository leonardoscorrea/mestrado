typedef struct linha Linha;
typedef struct matriz Matriz;
int somaElementosAcimaDiagonalPrincipal(int tamanhoMatris, int chaveAleatoriedade);
void criaVetor();
void criaVetorPredefinido(int tamanho, int tipo, int chaveAleatoriedade);
void adicionaValorVetor(int valor);
void ordenaVetor();
void ordenaVetorInsercao();