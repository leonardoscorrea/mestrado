#!/bin/sh
#DESENVOLVIDO POR Leonardo Correa

g++ -p complexidade.cpp principalComplexidade.cpp -o complex -lm
./complex

