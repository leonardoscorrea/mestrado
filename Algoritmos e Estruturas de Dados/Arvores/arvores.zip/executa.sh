#!/bin/sh
#DESENVOLVIDO POR Leonardo Correa

gcc -p arvoresBinarias.c principal.c -o principal -lm
./principal
